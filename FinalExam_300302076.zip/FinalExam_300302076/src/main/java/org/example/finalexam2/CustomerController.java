
package org.example.finalexam2;

import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.Optional;

@AllArgsConstructor
@Controller
public class CustomerController {

    @Autowired
    private CustomerRepository customerRepository;

    @GetMapping("/")
    public String seats(Model model) {

        model.addAttribute("seats", customerRepository.findAll());
        return "seats";
    }

    @PostMapping("/saveSeat")
    public String saveSeat(@RequestParam("seatcode") String seatCode,
                           @RequestParam("customerName") String customerName,
                           @RequestParam("seattime") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date transactionDate,
                           Model model) {

        if (!seatCode.matches("^[1-5][A-E]$")) {
            model.addAttribute("error", "Seat code is invalid.");
            model.addAttribute("seats", customerRepository.findAll()); // Re-add seats for rendering
            return "seats";
        }

        Customer customer = new Customer();
        customer.setSeatno(seatCode);
        customer.setName(customerName);
        customer.setDate(transactionDate);
        customerRepository.save(customer);

        model.addAttribute("seats", customerRepository.findAll());
        return "redirect:/";
    }

    @GetMapping("/form")
    public String customerform(Model model, int id) {

        Customer customer = customerRepository.findById(id).orElse(null);
        if (customer == null) throw new RuntimeException("Savings Account Does not exist");
        model.addAttribute("customer", customer);
        return "customerform";

    }

    @GetMapping(path = "/delete")
    public String delete(int id) {

        Optional<Customer> customer = customerRepository.findById(id);
        return "redirect:/";
    }

@PostMapping (path = "/addcustomer")
    public String addCustomer(Model model) {
        model.addAttribute("customer", new Customer());
        return "redirect:/";
    }

}
